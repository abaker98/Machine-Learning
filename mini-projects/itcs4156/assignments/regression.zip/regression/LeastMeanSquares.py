import numpy as np

from itcs4156.models.LinearModel import LinearModel

class LeastMeanSquares(LinearModel):
    """
        Performs regression using least mean squares (gradient descent)
    
        attributes:
            w (np.ndarray): weight matrix
            
            alpha (float): learning rate or step size
    """
    def __init__(self, alpha: float, epochs=1):
        super().__init__()
        self.w = None
        self.alpha = alpha
        self.epochs = epochs
       
    def train(self, X: np.ndarray, y: np.ndarray) -> None:
        """ Used to train our model to learn optimal weights.
        
            TODO:
                Finish this method by adding code to perform LMS in order to learn the 
                weights `self.w`.
        """
        m_samples = X.shape[0]
         
        rng = np.random.RandomState(42)
        
        self.w = rng.rand(X.shape[1])
        
        self.w_best = self.w.copy()
        
        for e in range(self.epochs):
            misclassified = 0
           
            for i in range(m_samples):
                
                z = self.w @ X[i]
                
                y_hat = np.sign(z)
                
                
                if y_hat != y[i]:
                    
                    self.w = self.w + self.alpha * y[i] * X[i]
                    
                replace_weights = self.replace_best_weights(X, y)
                if replace_weights is True:
                    print(f"\tUpdating best weights based on data sample {i+1}...")
                    self.w_best[:] = self.w[:]


                misclassified += 1
                    
                   
            
            if misclassified == 0:
                print(f"Converged at epoch: {e} - No samples misclassified")
                break
        
    def predict(self, X: np.ndarray) -> np.ndarray:
        """ Used to make a prediction using the learned weights.
        
            TODO:
                Finish this method by adding code to make a prediction given the learned
                weights `self.w`.
        """
        return np.sign(X @ self.w_best).reshape(-1,1)
    def replace_best_weights(self, X, y):
        
        preds_w = np.sign(X @ self.w)
        preds_w = preds_w.reshape(-1, 1)
        
        preds_w_best = np.sign(X @ self.w_best)
        preds_w_best = preds_w_best.reshape(-1, 1)
        
        total_corr_w = np.sum(preds_w == y)
        total_corr_w_best = np.sum(preds_w_best == y)
        
        if total_corr_w > total_corr_w_best:
            return True
        else:
            return False